/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mediatwelve;

import java.awt.Event;
import media.*;

/**
 *
 * @author Saryta
 */
public class MediaTwelve {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String file1 = "C:\\Users\\c0030622\\Desktop\\transfer\\_comp132_2015q2\\lectures\\ModIV\\MediaTwelve\\src\\mediatwelve\\butterfly.jpg";
        String file2 = "C:\\Users\\c0030622\\Desktop\\transfer\\_comp132_2015q2\\lectures\\ModIV\\MediaTwelve\\src\\mediatwelve\\beach.jpg";
        String file3 = "C:\\Users\\c0030622\\Desktop\\transfer\\_comp132_2015q2\\lectures\\ModIV\\MediaTwelve\\src\\mediatwelve\\kittenDress.jpg";

        Picture pic1 = new Picture(file1);
        Picture pic2 = new Picture(file2);
        Picture pic3 = new Picture(file3);
         pic1.drawGrid();
         pic1.show();
         pic2.drawSun();
         pic2.show();

         pic3.drawString("You know what I am asking!", 50);
        pic3.show();

         pic3.drawString("Why me?", 0.05);
        pic3.show();



    }
}
