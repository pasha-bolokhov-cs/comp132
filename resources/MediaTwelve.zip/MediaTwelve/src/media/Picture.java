package media;

import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.text.*;

/**
 * A class that represents a picture. This class inherits from SimplePicture and
 * allows the student to add functionality to the Picture class.
 *
 * Copyright Georgia Institute of Technology 2004-2005
 *
 * @author Barbara Ericson ericson@cc.gatech.edu
 */
public class Picture extends SimplePicture {
    ///////////////////// constructors //////////////////////////////////

    /**
     * Constructor that takes no arguments
     */
    public Picture() {
        /* not needed but use it to show students the implicit call to super()
         * child constructors always call a parent constructor 
         */
        super();
    }

    /**
     * Constructor that takes a file name and creates the picture
     *
     * @param fileName the name of the file to create the picture from
     */
    public Picture(String fileName) {
        // let the parent class handle this fileName
        super(fileName);
    }

    /**
     * Constructor that takes the width and height
     *
     * @param width the width of the desired picture
     * @param height the height of the desired picture
     */
    public Picture(int width, int height) {
        // let the parent class handle this width and height
        super(width, height);
    }

    /**
     * Constructor that takes a picture and creates a copy of that picture
     */
    public Picture(Picture copyPicture) {
        // let the parent class do the copy
        super(copyPicture);
    }

    ////////////////////// methods ///////////////////////////////////////
    /**
     * Method to return a string with information about this picture.
     *
     * @return a string with information about the picture such as fileName,
     * height and width.
     */
    public String toString() {
        String output = "Picture, filename " + getFileName()
                + " height " + getHeight()
                + " width " + getWidth();
        return output;

    }

    public void drawGrid() {
        //draw all the vertical lines
        for (int x = 20; x < this.getWidth(); x += 20) {
            for (int y = 0; y < this.getHeight(); y++) {
                this.getPixel(x, y).setColor(Color.BLACK);
            }
        }
        //draw all the horizontal lines
        for (int x = 0; x < this.getWidth(); x++) {
            for (int y = 20; y < this.getHeight(); y += 20) {
                this.getPixel(x, y).setColor(Color.BLACK);
            }
        }
    }

    public void drawSun() {
        Graphics g = this.getGraphics();
        g.setColor(Color.YELLOW);
        g.fillOval(155, 60, 20, 20);
    }

    /**
     * Method to draw a string near the bottom left of a picture. Nearness is
     * defined using a percentage of the pictures width. (e.g if a picture is
     * 100x200 in size, a 10% offset would place the string at (10, 190).
     *
     * @param howNear a percentage (0..1) defining how much to offset the string
     * from (0, height).
     *
     */
    public void drawString(String text, double howNear) {
        int leftX, baselineY, offset;
        //get the graphics object
        Graphics g = this.getGraphics();
        g.setColor(Color.YELLOW);
        g.setFont(new Font("Helvetica", Font.BOLD, 24));
        //calculate the pixel offset
        offset = (int) (this.getWidth() * howNear);
        //calculate the left x position and baseline
        leftX = offset;
        baselineY = this.getHeight() - offset;
        //draw the string
        g.drawString(text, leftX, baselineY);
    }

    public void drawString(String text, int baselineY) {
        int leftX, stringWidth, pictureMiddleX;
        //get the graphics object
        Graphics g = this.getGraphics();
        g.setColor(Color.BLACK);
        g.setFont(new Font("Helvetica", Font.BOLD, 24));
        //calculate the pixel x location
        FontMetrics currFontMetrics = g.getFontMetrics();
        // get the width of the string
        stringWidth = currFontMetrics.stringWidth(text);
        // get the middle of the picture
        pictureMiddleX = this.getWidth() / 2;
        // the middle of the string should align with the middle of the picture.  To do this we have to place the left edge of the string at pictureMiddleX - stringWidth/2
        leftX = pictureMiddleX - stringWidth / 2;
        g.drawString(text, leftX, baselineY);
    }
} // end of class Picture, put all new methods before this

