/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraymanipulation;


public class Arrays {
	private int[] dogs;
	private int logicalSize;
	
	//assumption: the array is full
	public Arrays(int[] temp) {
		dogs = temp;
		logicalSize = dogs.length;
	}
	
	// double the size of the original array
	// could be any algorithm for resizing
	private void resize(){
		int[] temp = new int[dogs.length * 2];
		for (int i = 0; i < dogs.length; i++){
			temp[i] = dogs[i];
		}
		dogs = temp;
	}
	
	//insert an element at the next available position (at the end of the of the list of valid data
	public void insert( int num ){
		
		if (dogs.length == logicalSize){
			resize();
		}
		
		dogs[logicalSize] = num;
		logicalSize++;
	}
	
	public void insertAfterIndex(int index, int num) {
		
		// if the index is invalid (we want to keep all the date together)
		if (index > logicalSize) {
			System.out.println("Please enter a valid index");
		} else if ( index == logicalSize ) {
			// if the index is the next spot, just call the other method
			insert(num);
		} else {
			if (dogs.length == logicalSize){
				resize();
			}
			
			for (int cur = logicalSize; cur > index; cur--) {
				dogs[cur] = dogs[cur-1];
			}
			
			dogs [index+1 ] = num;
			logicalSize++;
		}
	}
	
	// insert a number before a specific value
	// must look at each piece of data not each index
	public void insertBeforeElement(int value, int num){
		
		int cur;

		if (dogs.length == logicalSize){
			resize();
		}
		
		for (cur = logicalSize; cur > 0 && dogs[cur] != value ; cur--) {
			dogs[cur] = dogs[cur-1];
		}
		if (cur == 0) {
			System.out.println("The element does not exist, adding to the front of the list");
		}
		dogs [cur] = num;				
		logicalSize++;		
	}
	
	//reversing the array without changing the original one
	public int[] reverse(){
		int[] temp = new int[logicalSize];
		for (int i = logicalSize-1, j = 0; i > 0; i--, j++ ) {
			temp[j]= dogs[i];
		}
		
		return temp;
	}
	
	public void display(){
		
		for (int i = 0; i < logicalSize; i++){
			System.out.print(dogs[i] + "\t");
		}
		System.out.println();
	}
	

}

