
package arraymanipulation;

public class ArrayManipulation {

    public static void main(String[] args) {
        int[] donkey = new int[5];
        
        for (int i = 0; i < donkey.length; i++) {
            donkey[i] = i * 2 + 1;
        }
        
        Arrays obj = new Arrays(donkey);
        Arrays obj2 = new Arrays(donkey);
        obj.display();
        obj2.display();
        // donkey and horse are connected by reference
        
        donkey[0]=200;
        obj.display();
        obj2.display();

        obj.insert(11);
        obj.display();

        obj.insertAfterIndex(2, 6);
        obj.display();

        obj.insertBeforeElement(3, 2);
        obj.display();

        obj.insertBeforeElement(23, 0);
        obj.display();

        int[] saddle = obj.reverse();
        for (int i = 0; i < saddle.length; i++) {
            System.out.print(saddle[i] + "\t");
        }
        System.out.println();
    }

}
