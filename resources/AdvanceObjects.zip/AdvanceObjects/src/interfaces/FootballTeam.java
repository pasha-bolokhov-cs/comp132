package interfaces;

public interface FootballTeam {
	public void printFootballName();
}
