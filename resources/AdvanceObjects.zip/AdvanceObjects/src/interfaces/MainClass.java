/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author c0030622
 */
public class MainClass {

    public static void main(String[] args) {
        Team t = new Team("Team A:");
        t.printBasketballName();
        t.printFootballName();
    }
}
