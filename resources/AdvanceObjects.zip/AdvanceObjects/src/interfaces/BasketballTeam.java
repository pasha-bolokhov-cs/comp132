package interfaces;

public interface BasketballTeam {
	public void printBasketballName();
}
