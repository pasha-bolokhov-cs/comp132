package lab4;


/* 
  Reuse your logic from Lab 2
*/
public class Register {

    // instance variables to help you get started. 
    
    private int _100, _50, _20, _10, _5, _2, _1, quarter;
    private double remaining, amountReceived, changeDue;

    // default constructor
    public Register() {
   
    }

    // a method to return the change due and calculate the 
    // values within each denomination (only up to quarters. 
    public double change(double amountDue, double amountReceived) {
        /***** TO DO *****/
        return changeDue;
    }

    // string representation of the object. 
    public String toString() {
        /***** TO DO *****/
        return null;   
    }
}
