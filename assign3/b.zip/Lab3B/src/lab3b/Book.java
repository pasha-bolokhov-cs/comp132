package lab3b;

/**
 * @author: Book.java
 */
public class Book {

    /**
     * global variable to store the title of the book
     */
    private String title;

    /**
     * global variable to store the author of the book
     */
    private String author;

    /**
     * global variable to store the number of pages in a book
     */
    private int pages;

    /**
     * global variable to store the price of the book
     */
    double price;

    // ADD CODE HERE
    /**
     * Display some information about a particular book
     *
     * @param none
     * @return the output string
     */
    public String toString() {
        return null;
    }

}
